const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username:          { type: String, required: true, unique: true },
  email:             { type: String, required: true, unique: true },
  password:          { type: String, required: true },
  isVerified:        { type: Boolean, default: false },
  otp:               { type: String },
  otpExpiresAt:      { type: Date },
  profilePicture:    { type: String, default: '' },
  coverImage:        { type: String, default: '' },
  bio:               { type: String, default: '' },
}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function () {
  if (!this.isModified('password')) return;
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

module.exports = mongoose.model('User', userSchema);
